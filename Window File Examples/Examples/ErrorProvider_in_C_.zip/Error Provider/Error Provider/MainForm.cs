﻿/*
 * Created by SharpDevelop.
 * User: Administrator
 * Date: 9/21/2013
 * Time: 5:04 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Error_Provider
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		
		
		void Txt_nameValidating(object sender, System.ComponentModel.CancelEventArgs e)
		{
			if(txt_name.Text==string.Empty)
			{
				errorProvider1.SetError(txt_name,"Please Enter Name");
				errorProvider2.SetError(txt_name,"");
				errorProvider3.SetError(txt_name,"");
			}
			else
			{
				errorProvider1.SetError(txt_name,"");
				errorProvider2.SetError(txt_name,"");
				errorProvider3.SetError(txt_name,"Correct");
			}
		}
		
		void Txt_ageValidating(object sender, System.ComponentModel.CancelEventArgs e)
		{
			if(txt_age.Text==string.Empty)
			{
				errorProvider1.SetError(txt_age,"Please provide age");
				errorProvider2.SetError(txt_age,"");
				errorProvider3.SetError(txt_age,"");
			}
			else
			{
				Regex numberchk=new Regex(@"^([0-9]*|\d*)$");
				if(numberchk.IsMatch(txt_age.Text))
				{
					errorProvider1.SetError(txt_age,"");
					errorProvider2.SetError(txt_age,"");
					errorProvider3.SetError(txt_age,"Correct");
				}
				else
				{
					errorProvider1.SetError(txt_age,"");
					errorProvider2.SetError(txt_age,"Wrong format");
					errorProvider3.SetError(txt_age,"");
				}
			}
		}
	}
}
